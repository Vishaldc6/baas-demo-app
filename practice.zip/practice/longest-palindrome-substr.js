/**
 * Given a string s, return the longest palindromic substring in s.

Example 1:
Input: s = "babad"
Output: "bab"
Explanation: "aba" is also a valid answer.

Example 2:
Input: s = "cbbd"
Output: "bb"
*/



var longestPalindrome = function (s) {

    var expand = (i, j) => {
        let left = i, right = j
        while (left >= 0 && right < s.length && s[left] == s[right]) {
            left--
            right++
        }
        console.log({ left, right, s, out: s.slice(left + 1, right) });
        return s.slice(left + 1, right)
    }

    const mid = Math.floor(s.length / 2)

    if (s.length % 2 == 0) {
        // even len
        const res = expand(mid - 1, mid)
        return res.length ? res : s[0]
    } else {
        // old len
        return expand(mid, mid)
    }
};

// const s = "babad"
// Output: "bab"
// const s = "cbbd"
// Output: "bb"
// const s = "ac"
// Output: "a"
const s = "abb"
// Output: "bb"

console.log({ output: longestPalindrome(s) })