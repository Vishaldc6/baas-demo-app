/**
 * 2. Add Two Numbers
Medium
Topics
premium lock icon
Companies
You are given two non-empty linked lists representing two non-negative integers. The digits are stored in reverse order, and each of their nodes contains a single digit. Add the two numbers and return the sum as a linked list.

You may assume the two numbers do not contain any leading zero, except the number 0 itself.

Example 1:
Input: l1 = [2,4,3], l2 = [5,6,4]
Output: [7,0,8]
Explanation: 342 + 465 = 807.

Example 2:
Input: l1 = [0], l2 = [0]
Output: [0]

Example 3:
Input: l1 = [9,9,9,9,9,9,9], l2 = [9,9,9,9]
Output: [8,9,9,9,0,0,0,1]
 */

/**
 * Definition for singly-linked list.
 * function ListNode(val, next) {
 *     this.val = (val===undefined ? 0 : val)
 *     this.next = (next===undefined ? null : next)
 * }
 */
/**
 * @param {ListNode} l1
 * @param {ListNode} l2
 * @return {ListNode}
 */
/**
 * Array -> Linked List
 */
function createLinkedList(arr) {
    let dummy = new ListNode()
    let current = dummy
    for (let num of arr) {
        current.next = new ListNode(num)
        current = current.next
    }
    return dummy.next
}

/**
 * Linked List -> Array
 */
function printLinkedList(head) {
    let result = []
    while (head) {
        result.push(head.val)
        head = head.next
    }
    return result
}

function ListNode(val, next) {
    this.val = (val === undefined ? 0 : val)
    this.next = (next === undefined ? null : next)
}
let addTwoNumbers = function (l1, l2) {
    // output array approach
    // let outputList = []
    // let a = l1, b = l2
    // let rem = 0
    // while (a || b) {
    //     const sum = (a?.val ?? 0) + (b?.val ?? 0) + rem
    //     rem = Math.floor(sum / 10)
    //     outputList.push(sum % 10)
    //     a = a?.next
    //     b = b?.next
    // }
    // if (rem) outputList.push(rem)
    // return outputList

    let head = new ListNode()
    let current = head
    let a = l1, b = l2
    let rem = 0
    while (a || b) {
        const sum = (a?.val ?? 0) + (b?.val ?? 0) + rem
        rem = Math.floor(sum / 10)
        current.next = new ListNode(sum % 10)
        current = current.next
        a = a?.next
        b = b?.next
    }
    if (rem) current.next = new ListNode(rem)
    return head.next
};

// const l1 = [2, 4, 3], l2 = [5, 6, 4]
const l1 = createLinkedList([9, 9, 9, 9, 9, 9, 9])
const l2 = createLinkedList([9, 9, 9, 9])
// [7,0,8]
// const l1 = [0], l2 = [0]
// // [0]
// const l1 = [9,9,9,9,9,9,9], l2 = [9,9,9,9]
// // [8,9,9,9,0,0,0,1]


const output = addTwoNumbers(l1, l2)

// console.log({ output })
console.log(printLinkedList(output))
