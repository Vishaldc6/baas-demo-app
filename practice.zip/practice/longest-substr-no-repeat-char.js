/**
 * 3. Longest Substring Without Repeating Characters

Given a string s, find the length of the longest substring without duplicate characters.

Example 1:
Input: s = "abcabcbb"
Output: 3
Explanation: The answer is "abc", with the length of 3. Note that "bca" and "cab" are also correct answers.

Example 2:
Input: s = "bbbbb"
Output: 1
Explanation: The answer is "b", with the length of 1.

Example 3:
Input: s = "pwwkew"
Output: 3
Explanation: The answer is "wke", with the length of 3.

Notice that the answer must be a substring, "pwke" is a subsequence and not a substring.

Constraints:
0 <= s.length <= 5 * 104
s consists of English letters, digits, symbols and spaces.
 */

/**
 * @param {string} s
 * @return {number}
 */
let lengthOfLongestSubstring = function (s) {

    let set = new Set()
    let left = 0, maxLength = 0
    for (let right = 0; right < s.length; right++) {
        while (set.has(s[right])) {
            set.delete(s[left])
            left++
        }
        set.add(s[right])
        maxLength = Math.max(maxLength, set.size)
        console.log({ left, right, maxLength });
    }

    return maxLength

};

// const s = "abcabcbb"
// Output: 3
// const s = "bbbbb"
// Output: 1
const s = "pwwkew"
// Output: 3

console.log({ output: lengthOfLongestSubstring(s) });
